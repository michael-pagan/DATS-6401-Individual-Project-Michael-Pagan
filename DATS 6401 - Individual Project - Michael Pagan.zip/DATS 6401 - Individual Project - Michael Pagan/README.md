# DATS-6401-Individual-Project-Michael-Pagan
DATS 6401 - Individual Project - Michael Pagan

[![DOI](https://zenodo.org/badge/271670195.svg)](https://zenodo.org/badge/latestdoi/271670195)

[Link to Zenodo publication](https://zenodo.org/record/3891598#.XuOaG2pKjlw)

Investigating the GDP, military, health, and education spending of the G20 countries between 2010-2017.
