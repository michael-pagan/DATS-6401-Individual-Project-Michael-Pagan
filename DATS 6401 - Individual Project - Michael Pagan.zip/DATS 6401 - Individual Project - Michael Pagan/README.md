# DATS-6401-Individual-Project-Michael-Pagan
DATS 6401 - Individual Project - Michael Pagan

Published on [github.io](https://michael-pagan.github.io/DATS-6401-Individual-Project-Michael-Pagan/)

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.3891716.svg)](https://doi.org/10.5281/zenodo.3891716)

[Link to Zenodo publication](https://doi.org/10.5281/zenodo.3891716)

Investigating the GDP, military, health, and education spending of the G20 countries between 2010-2017.
